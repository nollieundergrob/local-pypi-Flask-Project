from django.apps import AppConfig


class DjangoRestframeworkConfig(AppConfig):
    name = 'django_restframework'
